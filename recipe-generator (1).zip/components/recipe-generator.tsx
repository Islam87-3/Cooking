"use client"

import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ChefHat, Sparkles } from "lucide-react"
import { RecipeCard } from "./recipe-card"

type GenerationMode = "generate-only" | "generate-suggest"
type FlavorType = "sweet" | "savory"

interface Recipe {
  title: string
  ingredients: string[]
  instructions: string[]
  cookingTime?: string
  servings?: string
}

export function RecipeGenerator() {
  const [ingredients, setIngredients] = useState("")
  const [mode, setMode] = useState<GenerationMode>("generate-suggest")
  const [flavor, setFlavor] = useState<FlavorType>("savory")
  const [isLoading, setIsLoading] = useState(false)
  const [recipe, setRecipe] = useState<Recipe | null>(null)
  const [hasGenerated, setHasGenerated] = useState(false)

  const generateRecipe = async () => {
    if (!ingredients.trim()) return

    setIsLoading(true)

    try {
      const response = await fetch("/api/generate-recipe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ingredients,
          mode,
          flavor,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate recipe")
      }

      const parsedRecipe = await response.json()
      setRecipe(parsedRecipe)
      setHasGenerated(true)
    } catch (error) {
      console.error("Error generating recipe:", error)
      setRecipe({
        title: `Delicious ${flavor.charAt(0).toUpperCase() + flavor.slice(1)} Creation`,
        ingredients: ingredients.split(",").map((ing) => ing.trim()),
        instructions: [
          "Prepare all ingredients according to your preferences.",
          "Combine ingredients thoughtfully.",
          "Cook with love and creativity.",
          "Serve and enjoy your creation!",
        ],
      })
      setHasGenerated(true)
    } finally {
      setIsLoading(false)
    }
  }

  const resetForm = () => {
    setIngredients("")
    setRecipe(null)
    setHasGenerated(false)
    setMode("generate-only")
    setFlavor("savory")
  }

  return (
    <div className="space-y-8 sm:space-y-10">
      <Card className="bg-card border-2 border-primary/20 shadow-xl card-hover">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b border-border">
          <CardTitle className="flex items-center gap-3 text-xl sm:text-2xl text-gradient">
            <ChefHat className="w-6 h-6 sm:w-7 sm:h-7 text-primary" />
            <span>Create Your Recipe</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 sm:p-6 md:p-8 space-y-6 sm:space-y-8">
          <div className="space-y-3 sm:space-y-4">
            <Label htmlFor="ingredients" className="form-label text-lg sm:text-xl">
              Available Ingredients
            </Label>
            <Textarea
              id="ingredients"
              placeholder="Enter your ingredients separated by commas (e.g., chicken, rice, onions, garlic...)"
              value={ingredients}
              onChange={(e) => setIngredients(e.target.value)}
              className="form-input min-h-[100px] sm:min-h-[120px] text-base sm:text-lg resize-none"
              disabled={isLoading}
            />
          </div>

          <div className="space-y-3 sm:space-y-4">
            <Label className="form-label text-lg sm:text-xl">Generation Mode</Label>
            <div className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2">
              <button
                onClick={() => setMode("generate-only")}
                disabled={isLoading}
                className={`surface-interactive flex items-start p-4 sm:p-5 border-2 rounded-lg transition-all cursor-pointer focus-ring ${
                  mode === "generate-only"
                    ? "bg-primary/10 border-primary shadow-md"
                    : "border-border hover:border-primary/50 hover:bg-muted/30"
                }`}
              >
                <div className="flex items-start gap-3 w-full">
                  <div
                    className={`w-4 h-4 rounded-full border-2 mt-1 transition-colors ${
                      mode === "generate-only" ? "bg-primary border-primary" : "border-muted-foreground"
                    }`}
                  />
                  <div className="flex-1 text-left">
                    <div className="font-semibold text-base sm:text-lg">Generate Only</div>
                    <div className="text-sm text-muted-foreground mt-1">Use listed ingredients only</div>
                  </div>
                </div>
              </button>

              <button
                onClick={() => setMode("generate-suggest")}
                disabled={isLoading}
                className={`surface-interactive flex items-start p-4 sm:p-5 border-2 rounded-lg transition-all cursor-pointer focus-ring ${
                  mode === "generate-suggest"
                    ? "bg-primary/10 border-primary shadow-md"
                    : "border-border hover:border-primary/50 hover:bg-muted/30"
                }`}
              >
                <div className="flex items-start gap-3 w-full">
                  <div
                    className={`w-4 h-4 rounded-full border-2 mt-1 transition-colors ${
                      mode === "generate-suggest" ? "bg-primary border-primary" : "border-muted-foreground"
                    }`}
                  />
                  <div className="flex-1 text-left">
                    <div className="font-semibold text-base sm:text-lg">Generate & Suggest</div>
                    <div className="text-sm text-muted-foreground mt-1">Add optional items if needed</div>
                  </div>
                </div>
              </button>
            </div>
          </div>

          <div className="space-y-3 sm:space-y-4">
            <Label className="form-label text-lg sm:text-xl">Flavor Profile</Label>
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
              <button
                onClick={() => setFlavor("sweet")}
                disabled={isLoading}
                className={`surface-interactive flex items-center gap-3 px-4 sm:px-6 py-3 rounded-lg border-2 transition-all focus-ring ${
                  flavor === "sweet"
                    ? "bg-primary/10 border-primary shadow-md"
                    : "border-border hover:border-primary/50 hover:bg-muted/30"
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full border-2 transition-colors ${
                    flavor === "sweet" ? "bg-primary border-primary" : "border-muted-foreground"
                  }`}
                />
                <span className="text-base sm:text-lg font-medium">🍰 Sweet</span>
              </button>

              <button
                onClick={() => setFlavor("savory")}
                disabled={isLoading}
                className={`surface-interactive flex items-center gap-3 px-4 sm:px-6 py-3 rounded-lg border-2 transition-all focus-ring ${
                  flavor === "savory"
                    ? "bg-primary/10 border-primary shadow-md"
                    : "border-border hover:border-primary/50 hover:bg-muted/30"
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full border-2 transition-colors ${
                    flavor === "savory" ? "bg-primary border-primary" : "border-muted-foreground"
                  }`}
                />
                <span className="text-base sm:text-lg font-medium">🍲 Savory</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:gap-4 pt-4 sm:pt-6">
            <Button
              onClick={generateRecipe}
              disabled={!ingredients.trim() || isLoading}
              className="w-full gradient-pink gradient-pink-hover text-white font-semibold py-3 sm:py-4 text-lg sm:text-xl btn-hover-scale focus-ring"
            >
              {isLoading ? (
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 sm:w-6 sm:h-6 animate-spin" />
                  <span>Generating...</span>
                </div>
              ) : hasGenerated ? (
                <div className="flex items-center gap-3">
                  <Sparkles className="w-5 h-5 sm:w-6 sm:h-6" />
                  <span>Try Again</span>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <ChefHat className="w-5 h-5 sm:w-6 sm:h-6" />
                  <span>Generate Recipe</span>
                </div>
              )}
            </Button>

            {hasGenerated && (
              <Button
                onClick={resetForm}
                variant="outline"
                className="w-full sm:w-auto sm:self-center sm:px-8 py-3 sm:py-4 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent text-base sm:text-lg font-semibold btn-hover-scale focus-ring"
              >
                New Recipe
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recipe Results */}
      {recipe && (
        <div className="fade-in-up">
          <RecipeCard recipe={recipe} />
        </div>
      )}
    </div>
  )
}
