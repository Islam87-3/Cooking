import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Users, ChefHat, Activity } from "lucide-react"

interface Recipe {
  title: string
  ingredients: string[]
  instructions: string[]
  cookingTime?: string
  servings?: string
  nutrition?: {
    calories: string
    protein: string
    carbs: string
    fat: string
    fiber: string
  }
}

interface RecipeCardProps {
  recipe: Recipe
}

export function RecipeCard({ recipe }: RecipeCardProps) {
  return (
    <article className="card-hover">
      <Card className="bg-card border-2 border-primary/20 shadow-xl bg-gradient-to-br from-card to-primary/5">
        <CardHeader className="bg-gradient-to-r from-primary to-secondary text-primary-foreground">
          <CardTitle className="text-3xl md:text-4xl font-bold text-center text-balance px-2 sm:px-0">
            {recipe.title}
          </CardTitle>
          <div className="flex flex-wrap gap-4 mt-6 justify-center sm:gap-3 sm:mt-4">
            {recipe.cookingTime && (
              <Badge
                variant="secondary"
                className="bg-white/20 text-white px-4 py-2 hover:bg-white/30 transition-colors sm:px-3"
              >
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 sm:w-4 sm:h-4" />
                  <span className="text-base font-medium sm:text-sm">{recipe.cookingTime}</span>
                </div>
              </Badge>
            )}
            {recipe.servings && (
              <Badge
                variant="secondary"
                className="bg-white/20 text-white px-4 py-2 hover:bg-white/30 transition-colors sm:px-3"
              >
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 sm:w-4 sm:h-4" />
                  <span className="text-base font-medium sm:text-sm">{recipe.servings}</span>
                </div>
              </Badge>
            )}
          </div>
        </CardHeader>

        <CardContent className="p-6 md:p-8 space-y-8 sm:p-4 sm:space-y-6">
          <section>
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 text-primary sm:text-xl sm:mb-4">
              <ChefHat className="w-6 h-6 sm:w-5 sm:h-5" />
              <span>Ingredients</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {recipe.ingredients.map((ingredient, index) => (
                <div
                  key={index}
                  className="bg-card border border-border shadow-md rounded-lg hover:shadow-lg hover:-translate-y-0.5 transition-all flex items-center gap-3 p-4 bg-muted/50 rounded-lg border hover:bg-muted/70 hover:border-primary/30 sm:p-3"
                >
                  <div className="w-3 h-3 bg-primary rounded-full flex-shrink-0" />
                  <span className="text-base font-medium text-pretty sm:text-sm">{ingredient}</span>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 text-primary sm:text-xl sm:mb-4">
              <span className="text-2xl sm:text-xl">📝</span>
              <span>Instructions</span>
            </h2>
            <ol className="space-y-4 sm:space-y-3">
              {recipe.instructions.map((instruction, index) => (
                <li
                  key={index}
                  className="bg-card border border-border shadow-md rounded-lg hover:shadow-lg hover:-translate-y-0.5 transition-all flex gap-4 p-5 bg-gradient-to-r from-muted/30 to-transparent rounded-lg border-l-4 border-l-primary hover:from-muted/50 sm:gap-3 sm:p-4"
                >
                  <div className="flex-shrink-0 w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-lg shadow-md sm:w-8 sm:h-8 sm:text-sm">
                    {index + 1}
                  </div>
                  <p className="text-base leading-relaxed font-medium flex-1 text-pretty sm:text-sm">{instruction}</p>
                </li>
              ))}
            </ol>
          </section>

          {recipe.nutrition && (
            <section>
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 text-primary sm:text-xl sm:mb-4">
                <Activity className="w-6 h-6 sm:w-5 sm:h-5" />
                <span>Nutritional Information</span>
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 sm:gap-3">
                <div className="nutrition-card calories">
                  <div className="text-red-600 dark:text-red-400 font-bold text-sm mb-1 sm:text-xs">Calories</div>
                  <div className="text-red-800 dark:text-red-300 font-bold text-xl sm:text-lg">
                    {recipe.nutrition.calories} <span className="text-sm sm:text-base">kcal</span>
                  </div>
                </div>
                <div className="nutrition-card protein">
                  <div className="text-blue-600 dark:text-blue-400 font-bold text-sm mb-1 sm:text-xs">Protein</div>
                  <div className="text-blue-800 dark:text-blue-300 font-bold text-xl sm:text-lg">
                    {recipe.nutrition.protein} <span className="text-sm sm:text-base">g</span>
                  </div>
                </div>
                <div className="nutrition-card carbs">
                  <div className="text-yellow-600 dark:text-yellow-400 font-bold text-sm mb-1 sm:text-xs">Carbs</div>
                  <div className="text-yellow-800 dark:text-yellow-300 font-bold text-xl sm:text-lg">
                    {recipe.nutrition.carbs} <span className="text-sm sm:text-base">g</span>
                  </div>
                </div>
                <div className="nutrition-card fat">
                  <div className="text-purple-600 dark:text-purple-400 font-bold text-sm mb-1 sm:text-xs">Fat</div>
                  <div className="text-purple-800 dark:text-purple-300 font-bold text-xl sm:text-lg">
                    {recipe.nutrition.fat} <span className="text-sm sm:text-base">g</span>
                  </div>
                </div>
                <div className="nutrition-card fiber col-span-2 sm:col-span-1">
                  <div className="text-green-600 dark:text-green-400 font-bold text-sm mb-1 sm:text-xs">Fiber</div>
                  <div className="text-green-800 dark:text-green-300 font-bold text-xl sm:text-lg">
                    {recipe.nutrition.fiber} <span className="text-sm sm:text-base">g</span>
                  </div>
                </div>
              </div>
            </section>
          )}

          <div className="pt-6 border-t-2 border-primary/20 text-center sm:pt-4">
            <div className="text-3xl mb-3 float-animation sm:text-2xl">🍽️✨🎉</div>
            <p className="text-muted-foreground text-lg font-medium text-balance sm:text-base">
              Enjoy your delicious creation!
            </p>
          </div>
        </CardContent>
      </Card>
    </article>
  )
}
