"use client"

import { useState, useEffect } from "react"

const phrases = ["Recipe Genie", "Cooking Magic", "Flavor Creator", "Kitchen Wizard", "Culinary AI", "Taste Maker"]

export function TypewriterHeader() {
  const [currentPhrase, setCurrentPhrase] = useState(0)
  const [currentText, setCurrentText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)
  const [isPaused, setIsPaused] = useState(false)

  useEffect(() => {
    const timeout = setTimeout(
      () => {
        const fullText = phrases[currentPhrase]

        if (isPaused) {
          setIsPaused(false)
          setIsDeleting(true)
          return
        }

        if (isDeleting) {
          setCurrentText(fullText.substring(0, currentText.length - 1))

          if (currentText === "") {
            setIsDeleting(false)
            setCurrentPhrase((prev) => (prev + 1) % phrases.length)
          }
        } else {
          setCurrentText(fullText.substring(0, currentText.length + 1))

          if (currentText === fullText) {
            setIsPaused(true)
          }
        }
      },
      isDeleting ? 80 : isPaused ? 2500 : 120,
    )

    return () => clearTimeout(timeout)
  }, [currentText, isDeleting, isPaused, currentPhrase])

  return (
    <div className="relative scale-in px-4 sm:px-0">
      <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-4 glow-hover text-center">
        <span className="inline-block min-w-[200px] sm:min-w-[300px] md:min-w-[400px] text-center">
          {currentText}
          <span className="animate-pulse text-secondary">|</span>
        </span>
      </h1>
      <div className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2 text-2xl sm:text-3xl md:text-4xl float-animation">
        ✨
      </div>
      <div
        className="absolute -bottom-1 -left-1 sm:-bottom-2 sm:-left-2 text-xl sm:text-2xl md:text-3xl float-animation"
        style={{ animationDelay: "-1.5s" }}
      >
        🍳
      </div>
    </div>
  )
}
