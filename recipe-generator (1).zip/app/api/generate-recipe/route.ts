import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { ingredients, mode, flavor } = await request.json()

    if (!ingredients) {
      return NextResponse.json({ error: "Ingredients are required" }, { status: 400 })
    }

    let prompt = `Create a ${flavor} recipe using these ingredients: ${ingredients}. `

    switch (mode) {
      case "generate-only":
        prompt += "Use ONLY the listed ingredients, no additional items."
        break
      case "generate-suggest":
        prompt += "Use the listed ingredients and suggest additional items if needed for a complete recipe."
        break
      case "suggest-only":
        prompt +=
          "Just suggest possible dish names that could be made with these ingredients, no detailed recipe needed."
        break
    }

    prompt += ` Format the response as valid JSON with these exact fields:
    {
      "title": "Recipe Title",
      "ingredients": ["ingredient 1", "ingredient 2"],
      "instructions": ["step 1", "step 2"],
      "nutrition": {
        "calories": "approximate calories",
        "protein": "protein in grams",
        "carbs": "carbohydrates in grams",
        "fat": "fat in grams",
        "fiber": "fiber in grams"
      }
    }
    Return ONLY valid JSON, no additional text.`

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer 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",
      },
      body: JSON.stringify({
        model: "deepseek/deepseek-chat-v3.1:free",
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to generate recipe")
    }

    const data = await response.json()
    let content = data.choices[0].message.content

    let parsedRecipe
    try {
      content = content.trim()

      if (content.startsWith("```json")) {
        content = content.replace(/```json\n?/, "").replace(/\n?```$/, "")
      } else if (content.startsWith("```")) {
        content = content.replace(/```\n?/, "").replace(/\n?```$/, "")
      }

      const jsonMatch = content.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        content = jsonMatch[0]
      }

      parsedRecipe = JSON.parse(content)

      if (!parsedRecipe.title || !parsedRecipe.ingredients || !parsedRecipe.instructions) {
        throw new Error("Invalid recipe format")
      }
    } catch (error) {
      console.error("JSON parsing failed:", error)
      const lines = content.split("\n").filter((line: string) => line.trim())

      let title =
        lines.find((line) => line.toLowerCase().includes("recipe") || !line.includes(":")) || "Generated Recipe"

      title = title
        .replace(/^#+\s*/, "")
        .replace(/^\*+\s*/, "")
        .trim()

      const ingredientsStart = lines.findIndex((line) => line.toLowerCase().includes("ingredient"))
      const instructionsStart = lines.findIndex(
        (line) => line.toLowerCase().includes("instruction") || line.toLowerCase().includes("step"),
      )

      let ingredients: string[] = []
      let instructions: string[] = []

      if (ingredientsStart !== -1 && instructionsStart !== -1) {
        ingredients = lines
          .slice(ingredientsStart + 1, instructionsStart)
          .filter((line) => line.trim())
          .map((line) => line.replace(/^[-*•]\s*/, "").trim())

        instructions = lines
          .slice(instructionsStart + 1)
          .filter((line) => line.trim())
          .map((line) =>
            line
              .replace(/^[-*•]\s*/, "")
              .replace(/^\d+\.\s*/, "")
              .trim(),
          )
      } else {
        const midPoint = Math.floor(lines.length / 2)
        ingredients = lines.slice(1, midPoint).map((line) => line.replace(/^[-*•]\s*/, "").trim())
        instructions = lines.slice(midPoint).map((line) =>
          line
            .replace(/^[-*•]\s*/, "")
            .replace(/^\d+\.\s*/, "")
            .trim(),
        )
      }

      parsedRecipe = {
        title,
        ingredients: ingredients.length > 0 ? ingredients : ["Ingredients not specified"],
        instructions: instructions.length > 0 ? instructions : ["Instructions not specified"],
        nutrition: {
          calories: "Not specified",
          protein: "Not specified",
          carbs: "Not specified",
          fat: "Not specified",
          fiber: "Not specified",
        },
      }
    }

    return NextResponse.json(parsedRecipe)
  } catch (error) {
    console.error("Error generating recipe:", error)
    return NextResponse.json({ error: "Failed to generate recipe" }, { status: 500 })
  }
}
