import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import "./globals.css"

export const metadata: Metadata = {
  title: "Recipe Genie - AI Recipe Generator | Create Delicious Recipes from Your Ingredients",
  description:
    "Transform your available ingredients into amazing recipes with AI. Generate sweet and savory dishes, get cooking instructions, and discover new culinary creations instantly.",
  keywords: [
    "recipe generator",
    "AI recipes",
    "cooking",
    "food generator",
    "sweet recipes",
    "savory recipes",
    "ingredient-based recipes",
    "cooking assistant",
    "meal planning",
    "culinary AI",
  ],
  authors: [{ name: "Recipe Genie" }],
  creator: "Recipe Genie",
  publisher: "Recipe Genie",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://recipe-genie.vercel.app",
    title: "Recipe Genie - AI Recipe Generator",
    description:
      "Transform your available ingredients into amazing recipes with AI. Generate sweet and savory dishes instantly.",
    siteName: "Recipe Genie",
  },
  twitter: {
    card: "summary_large_image",
    title: "Recipe Genie - AI Recipe Generator",
    description:
      "Transform your available ingredients into amazing recipes with AI. Generate sweet and savory dishes instantly.",
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
  },
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable}`}>
        <Suspense fallback={null}>{children}</Suspense>
        <Analytics />
      </body>
    </html>
  )
}
