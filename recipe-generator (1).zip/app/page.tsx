import { RecipeGenerator } from "@/components/recipe-generator"
import { TypewriterHeader } from "@/components/typewriter-header"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <img
          src="/cooking-utensils-watercolor-illustration.jpg"
          alt="Decorative watercolor cooking utensils illustration"
          className="absolute top-5 left-2 sm:top-10 sm:left-10 opacity-10 w-16 h-16 sm:w-24 sm:h-24 md:w-32 md:h-32 rotate-12 parallax-float"
        />
        <img
          src="/chef-hat-pink-illustration.jpg"
          alt="Decorative pink chef hat illustration"
          className="absolute top-8 right-2 sm:top-20 sm:right-20 opacity-10 w-12 h-12 sm:w-18 sm:h-18 md:w-24 md:h-24 -rotate-12 parallax-float"
        />
        <img
          src="/kitchen-ingredients-watercolor.jpg"
          alt="Decorative watercolor kitchen ingredients illustration"
          className="absolute bottom-20 left-2 sm:bottom-32 sm:left-16 opacity-10 w-16 h-16 sm:w-20 sm:h-20 md:w-28 md:h-28 rotate-45 parallax-float"
        />
        <img
          src="/recipe-book-pink-illustration.jpg"
          alt="Decorative pink recipe book illustration"
          className="absolute bottom-24 right-2 sm:bottom-40 sm:right-12 opacity-10 w-14 h-14 sm:w-20 sm:h-20 md:w-26 md:h-26 -rotate-45 parallax-float"
        />
      </div>

      <header className="relative z-10 pt-8 sm:pt-12">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-12 sm:mb-16">
            <TypewriterHeader />
            <div className="mt-6 sm:mt-8 space-y-4 fade-in-up" style={{ animationDelay: "0.3s" }}>
              <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed px-4 sm:px-0">
                Transform your available ingredients into delicious recipes with the power of AI. Choose your cooking
                style and let the magic happen!
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 relative z-10 slide-in-right" style={{ animationDelay: "0.2s" }}>
        <div className="container mx-auto px-4 sm:px-6 pb-8 sm:pb-12">
          <article className="max-w-5xl mx-auto">
            <RecipeGenerator />
          </article>
        </div>
      </main>

      <footer className="mt-16 sm:mt-20 bg-primary py-6 relative z-10 fade-in-up" style={{ animationDelay: "0.4s" }}>
        <div className="container mx-auto px-4 sm:px-6">
          <nav className="text-center mb-4">
            <div className="flex flex-wrap justify-center gap-3 sm:gap-6 text-primary-foreground text-sm sm:text-base">
              <a
                href="/"
                className="link-hover hover:text-primary-foreground/80 transition-colors font-medium px-2 py-1"
              >
                Home
              </a>
              <a
                href="/recipes"
                className="link-hover hover:text-primary-foreground/80 transition-colors font-medium px-2 py-1"
              >
                Recipes
              </a>
              <a
                href="/desserts"
                className="link-hover hover:text-primary-foreground/80 transition-colors font-medium px-2 py-1"
              >
                Desserts
              </a>
              <a
                href="/savory-dishes"
                className="link-hover hover:text-primary-foreground/80 transition-colors font-medium px-2 py-1 hidden sm:inline"
              >
                Savory Dishes
              </a>
              <a
                href="/contact"
                className="link-hover hover:text-primary-foreground/80 transition-colors font-medium px-2 py-1"
              >
                Contact
              </a>
              <a
                href="/about"
                className="link-hover hover:text-primary-foreground/80 transition-colors font-medium px-2 py-1"
              >
                About
              </a>
            </div>
          </nav>
          <div className="text-center">
            <p className="text-primary-foreground text-sm sm:text-base font-medium px-4">
              © 2024 Recipe Genie - Where ingredients meet imagination!
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
